--------------------
Extra: getYoutube
--------------------
Version: 1.2.1-pl
Released: August 2, 2019
Since: February 25, 2014
Author: David Pede <dev@tasianmedia.com> <https://twitter.com/davepede>
Copyright: (C) 2019 David Pede. All rights reserved. <dev@tasian.media>

A simple video retrieval Snippet for MODX Revolution.

Official Documentation:
http://rtfm.modx.com/extras/revo/getyoutube

GitHub Repository:
http://github.com/tasianmedia/getYoutube

Bugs & Feature Requests:
http://github.com/tasianmedia/getYoutube/issues

Please Note:
getYoutube is not associated with or endorsed by YouTube, LLC.

License:
Released under the GNU General Public License; either version 2 of the License, or (at your option) any later version.
http://www.gnu.org/licenses/gpl.html